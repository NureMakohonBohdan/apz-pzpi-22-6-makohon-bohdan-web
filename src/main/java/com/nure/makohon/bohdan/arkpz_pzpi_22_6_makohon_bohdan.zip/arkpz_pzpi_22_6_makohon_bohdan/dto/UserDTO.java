package com.nure.makohon.bohdan.arkpz_pzpi_22_6_makohon_bohdan.dto;

import lombok.Data;

@Data
public class UserDTO {
    private Integer id;
    private String email;
    private String password;
}
