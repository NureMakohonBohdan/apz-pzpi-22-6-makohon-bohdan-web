package com.nure.makohon.bohdan.arkpz_pzpi_22_6_makohon_bohdan.entity;

public enum NotificationPreference {
    EMAIL, SMS, APP
}
