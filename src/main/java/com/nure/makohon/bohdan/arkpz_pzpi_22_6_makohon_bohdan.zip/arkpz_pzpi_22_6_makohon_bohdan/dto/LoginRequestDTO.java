package com.nure.makohon.bohdan.arkpz_pzpi_22_6_makohon_bohdan.dto;

import lombok.Data;

@Data
public class LoginRequestDTO {
    private String email;
    private String password;
}
